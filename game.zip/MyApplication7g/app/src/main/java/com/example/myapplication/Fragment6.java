package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.databinding.Fragment6Binding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;


public class Fragment6 extends Fragment {
    int a = 0;

    private Fragment6Binding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = Fragment6Binding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {

        binding.button.setAlpha(0.0F);
        super.onViewCreated(view, savedInstanceState);
        binding.buttonSecond5.setVisibility(View.INVISIBLE);
        Toast toast2 = Toast.makeText(getContext(),
                "Жилой квартал", Toast.LENGTH_LONG);
        toast2.setGravity(50, -15, -15);
        toast2.show();

        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.button.setAlpha(0.15F);
                if (a == 0) {
                    ShowDialogueMessage.show(getContext(),
                            "Мысли",
                            "Дверь заперта, нужно больше усилий чтобы ее открыть",
                            "Понятно"
                    );
                    a++;

                } else if (a < 9) {

                    a++;

                } else {
                    binding.buttonSecond5.setVisibility(View.VISIBLE);
                    Event.saveEvent(Const.Door6);
                }
            }
        });
        binding.buttonSecond5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                NavHostFragment.findNavController(Fragment6.this)

                        .navigate(R.id.action_fragment6_to_fragment7);

            }
        });
        binding.buttonSecond8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                NavHostFragment.findNavController(Fragment6.this)

                        .navigate(R.id.action_fragment6_to_ylicFragment);

            }
        });
        binding.buttonFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Fragment6.this)
                        .navigate(R.id.action_fragment6_to_fragment5);

            }

        });
        if (Event.haveEvent(Const.Door6)) {
            a = 100;
            binding.button.setAlpha(0.15F);
            binding.buttonSecond5.setVisibility(View.VISIBLE);
        }else{
            a=0;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}