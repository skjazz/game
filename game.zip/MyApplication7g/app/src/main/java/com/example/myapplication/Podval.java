package com.example.myapplication;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.databinding.PodvalBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;


public class Podval extends Fragment {


MediaPlayer batareyka;
MediaPlayer frpodval;




    private PodvalBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        binding = PodvalBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }




    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        frpodval = MediaPlayer.create(getContext(), R.raw.frpodval);
       batareyka= MediaPlayer.create(getContext(), R.raw.batareyka);
       frpodval.start();
        binding.button11.setVisibility(View.INVISIBLE);
        binding.button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                binding.button9.setVisibility(View.VISIBLE);
                if (Event.haveEvent(Const.ELECTRO_IS_WORKED2)) {
                    binding.button8.setVisibility(View.VISIBLE);
                    binding.button10.setVisibility(View.VISIBLE);
                    binding.button9.setVisibility(View.INVISIBLE);
                    binding.button11.setVisibility(View.VISIBLE);
                }

                else if (Event.haveEvent(Const.BATTARY_FULL)) {
                    binding.button8.setVisibility(View.VISIBLE);
                    binding.button10.setVisibility(View.VISIBLE);
                    binding.button9.setVisibility(View.INVISIBLE);

                }

            }
        });
        binding.btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                NavHostFragment.findNavController(Podval.this)

                        .popBackStack();
            }
        });
        ShowDialogueMessage.show(getContext(),
                "Мысли",
                "Похоже на Радиостанцию ",
                "Понятно"
        );

        Toast toast2 = Toast.makeText(getContext(),
                "Радиостанция", Toast.LENGTH_LONG);
        toast2.setGravity(50, -15, -15);
        toast2.show();
        binding.button8.setVisibility(View.INVISIBLE);
        binding.button9.setVisibility(View.INVISIBLE);
        binding.button10.setVisibility(View.INVISIBLE);

        super.onViewCreated(view, savedInstanceState);
        if (Event.haveEvent(Const.BUCKET_WITH_WATER)) {
            binding.button8.setVisibility(View.VISIBLE);



            if (Event.haveEvent(Const.BATTARY)) {
                binding.button8.setVisibility(View.INVISIBLE);
                binding.button9.setVisibility(View.INVISIBLE);
            }


            if (Event.haveEvent(Const.ELECTRO_IS_WORKED2)) {
                binding.button8.setVisibility(View.VISIBLE);

            }



            binding.button9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    binding.button8.setVisibility(View.INVISIBLE);
                    binding.button9.setVisibility(View.INVISIBLE);

                    if (!Event.haveEvent(Const.BATTARY)) {
                        Toast toast2 = Toast.makeText(getContext(),
                                "Вы получили Аккамулятор. Нужно его зарядить", Toast.LENGTH_LONG);
                        toast2.setGravity(0, -15, -15);
                        toast2.show();
                        batareyka.start();
                    }

                    Event.saveEvent(Const.BATTARY);
                }
            });
            binding.button10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Event.saveEvent(Const.GOODEND);
                    NavHostFragment.findNavController(Podval.this)

                            .navigate(R.id.action_podval_to_ENDFragment);

                }
            });
            binding.button11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    NavHostFragment.findNavController(Podval.this)

                            .navigate(R.id.action_podval_to_desertFragment);
                    Event.saveEvent(Const.BADEND);

                }
            });

        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        frpodval.stop();
    }

}