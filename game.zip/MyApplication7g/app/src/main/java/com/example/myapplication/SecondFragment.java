package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.FragmentSecondBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;

public class SecondFragment extends Fragment {


    MainActivity class1 = new MainActivity();
    thirdFragment class2 = new thirdFragment();


    private FragmentSecondBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        Event.saveEvent(Const.GAME);

        binding.buttonSecond2.setVisibility(View.INVISIBLE);
        binding.buttonSecond3.setVisibility(View.INVISIBLE);
        binding.generatorEntrance.setAlpha(0.0F);
        binding.buttonSecond1.setAlpha(0.0F);
        if (Event.haveEvent(Const.SECOND_FRAGMENT2)) {
            binding.buttonSecond2.setVisibility(View.VISIBLE);
            binding.generatorEntrance.setAlpha(0.15F);
        }
        if (Event.haveEvent(Const.SECOND_FRAGMENT1)) {
            binding.buttonSecond3.setVisibility(View.VISIBLE);
            binding.buttonSecond1.setAlpha(0.15F);

        }



        Toast toast2 = Toast.makeText(getContext(),
                "Индустриальная часть города", Toast.LENGTH_LONG);
        toast2.setGravity(50, -15, -15);
        toast2.show();

        binding.generatorEntrance.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Event.saveEvent(Const.SECOND_FRAGMENT2);
                binding.generatorEntrance.setVisibility(View.VISIBLE);
                binding.generatorEntrance.setAlpha(0.15F);
                binding.buttonSecond2.setVisibility(View.VISIBLE);
                binding.buttonSecond2.setEnabled(true);

            }
        });

        binding.buttonSecond1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Event.saveEvent(Const.SECOND_FRAGMENT1);
                binding.buttonSecond3.setVisibility(View.VISIBLE);
                binding.buttonSecond3.setEnabled(true);
                binding.buttonSecond1.setAlpha(0.15F);
            }


        });
        binding.buttonSecond2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_thirdFragment);
                if (!Event.haveEvent(Const.ELECTRO_IS_WORKED)||!Event.haveEvent(Const.BATTARY_FULL)) {

                    ShowDialogueMessage.show(getContext(),
                            "Мысли",
                            "Провода кто то оборвал. Без них прибор не запустится",
                            "Понятно"
                    );

                }

            }


        });
        binding.buttonSecond3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_fragment_four);
                ShowDialogueMessage.show(getContext(),
                        "Мысли",
                        "Это похоже на мастерскую. Для меня тут нет ничего интересного",
                        "Понятно"
                );
            }
        });

    }

    @Override
    public void onDestroyView() {

        super.onDestroyView();
        binding = null;
    }


}