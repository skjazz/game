package com.example.myapplication;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import static java.security.AccessController.getContext;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.databinding.ContentMainBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.orm.SugarContext;
import com.orm.SugarDb;

import android.view.Menu;
import android.view.MenuItem;


import android.view.Menu;
import android.view.View;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private MediaPlayer atmSound;

    private void fillData() {
        long count = Event.count(Event.class, "", new String[]{});

        if (count > 0) {
            return;
        }

    }

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Thread t3 = new Thread(() -> {

            try {
                Thread.sleep(15000);

            } catch (InterruptedException ea) {
                return;

            }
            atmSound = MediaPlayer.create(this, R.raw.soundtrack);
            atmSound.start();
        });
t3.start();
        binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Navigation.findNavController(MainActivity.this, R.id.nav_host_fragment_content_main)
                        .navigate(R.id.action_global_settings);

            }
        });
        binding.floatingActionButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



if(!Event.haveEvent(Const.RobotFinded)) {
    Toast toast = Toast.makeText(getApplicationContext(),
            "Мне кажется стоит по лучше изучить город.", Toast.LENGTH_SHORT);
    toast.show();

}

                if(!Event.haveEvent(Const.BUCKET)&&Event.haveEvent(Const.RobotFinded)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Может что-нибудь найдется в индустриальной части города что сможет помочь роботу?", Toast.LENGTH_SHORT);
                    toast.show();

                }

                if(!Event.haveEvent(Const.WATERROM_IS_WORKED)&&Event.haveEvent(Const.BUCKET)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Что то нужно сделать с ведром. Только вот что?", Toast.LENGTH_SHORT);
                    toast.show();

                }
                if(!Event.haveEvent(Const.BATTARY)&&Event.haveEvent(Const.WATERROM_IS_WORKED)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Похоже я что то упустил... Может быть сейчас я могу дальше исследовать город?", Toast.LENGTH_SHORT);
                    toast.show();

                }
                if(!Event.haveEvent(Const.BATTARY_FULL)&&Event.haveEvent(Const.BATTARY)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Мне кажется этот аккамулятор мне как то сможет помочь. Нужно найти что то, что может зарядить его", Toast.LENGTH_SHORT);
                    toast.show();

                }
                if(!Event.haveEvent(Const.ROBOT)&&Event.haveEvent(Const.BATTARY_FULL)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Может быть этот аккамулятор пригодится роботу?", Toast.LENGTH_SHORT);
                    toast.show();

                }
                if(!Event.haveEvent(Const.BATTARYIFFULL2)&&Event.haveEvent(Const.ROBOT)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Робот попросил меня еще раз зарядить аккамулятор", Toast.LENGTH_SHORT);
                    toast.show();

                }
                if(Event.haveEvent(Const.ELECTRO_IS_WORKED)&&(!Event.haveEvent(Const.GOODEND)||!Event.haveEvent(Const.BADEND))) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Похоже аккамулятор не получится зарядить. Может быть в Радиостанции что-нибудь придумаю...", Toast.LENGTH_SHORT);
                    toast.show();

                }


            }
        });
//        getSupportActionBar().hide();
//        setSupportActionBar(binding.toolbar);


//        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

//        binding.fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAnchorView(R.id.fab)
//                        .setAction("Action", null).show();
//            }
//        });
    }

    private void soundPlay(MediaPlayer sound) {
        if (!sound.isPlaying()) {
            sound.start();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_SecondFragment_to_thirdFragment) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

}