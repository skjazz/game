package com.example.myapplication;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.databinding.Fragment5Binding;
import com.example.myapplication.databinding.FragmentFourBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;


public class Fragment5 extends Fragment {

    private Fragment5Binding binding;
MediaPlayer frfive;
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = Fragment5Binding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        frfive = MediaPlayer.create(getContext(), R.raw.frfive);
       frfive.start();
        binding.buttonFragment55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Fragment5.this)
                        .navigate(R.id.action_fragment5_to_fragment6);
                if (!Event.haveEvent(Const.IZYCHITRAION)) {
                    ShowDialogueMessage.show(getContext(),
                            "Мысли",
                            "Кажется нужно изучить этот район",
                            "Понятно"
                    );
                    Event.saveEvent(Const.IZYCHITRAION);
                }
            }
        });
        binding.buttonFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Fragment5.this)
                        .popBackStack();

            }
        });

        binding.button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Fragment5.this)
                        .navigate(R.id.action_fragment5_to_fragment8);


            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        frfive.stop();
    }

}