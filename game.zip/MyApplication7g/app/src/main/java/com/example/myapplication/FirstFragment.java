package com.example.myapplication;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.FragmentFirstBinding;
import com.example.myapplication.databinding.FragmentFourBinding;
import com.example.myapplication.ui.ShowDialogueMessage;

public class FirstFragment extends Fragment {


    private FragmentFirstBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
//        Toast toast = Toast.makeText(getContext(),
//                "Вы  в пустыне. Вы совсем не помните кем были до того как очнулись.", Toast.LENGTH_LONG);
//        toast.show();

        ShowDialogueMessage.show(getContext(),
                "Мысли",
                "Я в пустыне. Кажется я совсем не помню кем я был до того как очнулся",
                "Понятно"
        );



        binding.button3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
                ShowDialogueMessage.show(getContext(),
                        "Мысли",
                        "Нужно осмотреть здания, вдруг найдется что то что мне интересно",
                        "Понятно"
                );
//                toast.cancel();



            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}