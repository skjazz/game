package com.example.myapplication;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.databinding.FragmentFourBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;

public class Fragment_four extends Fragment {
    private FragmentFourBinding binding;
    MediaPlayer bucket;
    private long idmodel;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFourBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        bucket = MediaPlayer.create(getContext(), R.raw.bucket);
        super.onViewCreated(view, savedInstanceState);
        binding.but5.setVisibility(View.INVISIBLE);
        //   List<Vocabulary> x = Vocabulary.listAll(Vocabulary.class)
        if (Event.haveEvent(Const.BUCKET_WITH_get)) {
            binding.but5.setVisibility(View.INVISIBLE);
        }
        if (Event.haveEvent(Const.RobotFinded)&&(!Event.haveEvent(Const.BUCKET_WITH_get))) {
            binding.but5.setAlpha(0.15F);
            binding.but5.setVisibility(View.VISIBLE);
        }
        binding.but999.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Fragment_four.this)
                        .navigate(R.id.action_fragment_four_to_fragment5);


            }
        });

        binding.but4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Fragment_four.this)
                        .navigate(R.id.action_fragment_four_to_SecondFragment);


            }
        });

        binding.but5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Event.haveEvent(Const.RobotFinded)&&(!Event.haveEvent(Const.BUCKET_WITH_get))) {
                    binding.but5.setAlpha(0.15F);
                    binding.but5.setVisibility(View.INVISIBLE);
                    binding.but5.setEnabled(false);
                    Toast toast2 = Toast.makeText(getContext(),
                            "Вы получили Ведро", Toast.LENGTH_LONG);
                    toast2.setGravity(0, -15, -15);
                    toast2.show();
                    bucket.start();
                    binding.but5.setAlpha(0.15F);
                    Event.saveEvent(Const.BUCKET);
                    Event.saveEvent(Const.BUCKET_WITH_get);
                }else{
                    binding.but5.setAlpha(0.15F);
                    binding.but5.setVisibility(View.INVISIBLE);
                }
            }
        });


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
