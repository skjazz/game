package com.example.myapplication;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.databinding.Fragment8Binding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;

public class Fragment8 extends Fragment {

    boolean vospominania2=false;
    private Fragment8Binding binding;
MediaPlayer bucketwater;
MediaPlayer fragmeigh;
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState

    )
    {

        binding = Fragment8Binding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        bucketwater = MediaPlayer.create(getContext(), R.raw.bucketwater);
        fragmeigh = MediaPlayer.create(getContext(), R.raw.fragmeigh);
        fragmeigh.start();
        Toast toast3 = Toast.makeText(getContext(),

                "Хм, это место кажется мне знакомым.В главном насосе осталась какая то жидкость.", Toast.LENGTH_LONG);
        Thread t100 = new Thread(() -> {
            if (!Event.haveEvent(Const.Vospominanie2)){
            try {
                Thread.sleep(9000);

            } catch (InterruptedException ea) {
                return;
            }


                Event.saveEvent(Const.Vospominanie2);

                toast3.show();

            }
        });
        t100.start();
        binding.button7.setVisibility(View.INVISIBLE);
        super.onViewCreated(view, savedInstanceState);
        Toast toast2 = Toast.makeText(getContext(),
                "Водозаборная насосная станция", Toast.LENGTH_LONG);
        toast2.setGravity( 50, -15,-15);
        toast2.show();

        if(Event.haveEvent(Const.WATERROM_IS_WORKED)){
            binding.button6.setVisibility(View.INVISIBLE);

            binding.button7.setVisibility(View.INVISIBLE);
        }
        binding.button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t100.interrupt();
                NavHostFragment.findNavController(Fragment8.this)
                        .popBackStack();

            }
        });
        if(Event.haveEvent(Const.BUCKET)&&!Event.haveEvent(Const.WATERROM_IS_WORKED)){
            binding.button6.setAlpha(0.15F);
            binding.button6.setVisibility(View.VISIBLE);
            Event.saveEvent(Const.WATERROM_IS_WORKED);
        }else{
            binding.button6.setVisibility(View.INVISIBLE);

        }
    binding.button6.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
       binding.button7.setVisibility(View.VISIBLE);


        }
    });
        binding.button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast toast2 = Toast.makeText(getContext(),
                        "Вы заполнили ведро водой", Toast.LENGTH_LONG);
                toast2.setGravity( 0, -15,-15);

                if(Event.haveEvent(Const.BUCKET)) {
                    bucketwater.start();
                    binding.button6.setVisibility(View.INVISIBLE);
                    toast2.show();
                    binding.button7.setVisibility(View.INVISIBLE);
                    Event.saveEvent(Const.BUCKET_WITH_WATER);
                }
            }
        });
}

        @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
            fragmeigh.stop();
    }

}
