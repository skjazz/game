package com.example.myapplication;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.databinding.FragmentThirdBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;
import com.google.android.material.progressindicator.BaseProgressIndicator;


public class thirdFragment extends Fragment {
    private MediaPlayer otkaz;
    private MediaPlayer generator;
    int a=0;

    private FragmentThirdBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        binding = FragmentThirdBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }


    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        otkaz = MediaPlayer.create(getContext(), R.raw.otkaz);
        generator = MediaPlayer.create(getContext(), R.raw.generator);

        super.onViewCreated(view, savedInstanceState);
        binding.button8.setVisibility(View.INVISIBLE);
        binding.button9.setVisibility(View.INVISIBLE);
        if (Event.haveEvent(Const.WATERROM_IS_WORKED)&&Event.haveEvent(Const.BATTARY)) {
            binding.button8.setVisibility(View.VISIBLE);
        }
        if (Event.haveEvent(Const.BATTARY_FULL)) {
            binding.button8.setVisibility(View.INVISIBLE);
            binding.button9.setVisibility(View.INVISIBLE);
            binding.button9.setVisibility(View.INVISIBLE);
        }

        if (Event.haveEvent(Const.RADIOQUEST)){
            binding.button8.setVisibility(View.VISIBLE);
        }
        if (Event.haveEvent(Const.ELECTRO_IS_WORKED2)) {

            binding.button8.setVisibility(View.INVISIBLE);
            binding.button9.setVisibility(View.INVISIBLE);

        }
        Toast toast = Toast.makeText(getContext(),

                "Хм, это место кажется мне знакомым. Это запасной генератор города.", Toast.LENGTH_LONG);
        Thread t100 = new Thread(() -> {
            try {
                Thread.sleep(13000);

            } catch (InterruptedException ea) {
                return;
            }
            if (!Event.haveEvent(Const.Vospominanie1)) {
                Event.saveEvent(Const.Vospominanie1);

                toast.show();

            }

        });
        t100.start();

        binding.btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t100.interrupt();


                NavHostFragment.findNavController(thirdFragment.this)
                        .navigate(R.id.action_thirdFragment_to_SecondFragment);
            }
        });

        binding.button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                binding.button9.setVisibility(View.VISIBLE);


            }
        });


        binding.button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    binding.button8.setVisibility(View.INVISIBLE);
                    binding.button9.setVisibility(View.INVISIBLE);
                    a++;
                    if (Event.haveEvent(Const.RADIOQUEST)) {

                        if (a == 1) {
                            otkaz.start();
                            ShowDialogueMessage.show(getContext(),
                                    "Мысли",
                                    "Кажется не получилось, стоит попробовать еще раз",
                                    "Понятно"
                            );

                            binding.button8.setVisibility(View.VISIBLE);
                            binding.button9.setVisibility(View.VISIBLE);

                        }
                        if (a == 2) {
                            Event.saveEvent(Const.ELECTRO_IS_WORKED);
                            Event.saveEvent(Const.ELECTRO_IS_WORKED2);
                            otkaz.start();
                            ShowDialogueMessage.show(getContext(),
                                    "Мысли",
                                    "Запасная энергия в генераторе закончилась. Нужен другой способ.",
                                    "Понятно"
                            );


                        }
                    } else if (!Event.haveEvent(Const.BATTARY_FULL)) {
generator.start();
                        ShowDialogueMessage.show(getContext(),
                                "Мысли",
                                "Получилось! Прибор работает и батарея заполненна!",
                                "Понятно"
                        );

                        Event.saveEvent(Const.BATTARY_FULL);
                    }
                    if (Event.haveEvent(Const.ELECTRO_IS_WORKED2)) {

                        binding.button8.setVisibility(View.INVISIBLE);
                        binding.button9.setVisibility(View.INVISIBLE);

                    }
                }


        });


}

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}